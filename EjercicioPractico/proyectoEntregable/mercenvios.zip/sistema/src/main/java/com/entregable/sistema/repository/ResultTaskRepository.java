package com.entregable.sistema.repository;

import com.entregable.sistema.model.ResultTask;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResultTaskRepository extends JpaRepository<ResultTask, Integer> {
}