package com.bsoft.mercadoEnvios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MercadoEnviosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MercadoEnviosApplication.class, args);
	}

}
