package com.bsoft.mercadoEnvios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MercadoEnviosApplicationTests {

	@Test
	void contextLoads() {
	}

}
